from flask import Flask, request, render_template,redirect,flash
import pickle
import numpy as np
from pymongo import MongoClient
# Connection URL
url = "mongodb+srv://<username>:<passsword>@cluster0.ysxf9yn.mongodb.net/?retryWrites=true&w=majority"

# Database Name
db_name = 'student_users'  # Replace with your database name

# Create a new MongoClient
client = MongoClient(url)

# Connect to MongoDB
db = client[db_name]

# Collection Name
collection_name = db['user_details']
#new_user = {'name': "siva", 'email': "siva@gmail.com", 'password': "siva"}
#collection_name.insert_one(new_user)

app3 = Flask(__name__)

# Load the pickle model
model =pickle.load(open("new_theory_model.pkl", 'rb'))
model1=pickle.load(open("new_theory_model_with_6_marks.pkl",'rb'))
model2 = pickle.load(open("new_practical_model.pkl",'rb'))
@app3.route('/')
def home():
    return render_template('login_form.html')


@app3.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':
        # Get form data
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        # Insert data into MongoDB
        collection = db['user_details']
        new_user = {'name': name, 'email': email, 'password': password}
        result = collection.insert_one(new_user)
        print('Document inserted successfully:', result.inserted_id)



    return render_template('reg_form.html') # Render registration form template

@app3.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get form data
        email = request.form['email']
        password = request.form['password']

        # Check if email and password match a user in MongoDB
        user = collection_name.find_one({'email': email, 'password': password})

        if user:
            # Redirect to home page after successful login
            return redirect('/inputs')
        else:
            # Display error message for invalid login
            error_message = 'Invalid email or password'
            return render_template('login_form.html', error=error_message)
    else:
        return render_template('login_form.html')


@app3.route('/inputs')
def inputs():
    return render_template("inputs_get.html")
@app3.route('/theory-paper-cie')
def theory():
    return render_template("inputs_get.html")
@app3.route('/about')
def about():
    return render_template("about.html")
@app3.route('/help')
def help():
    return render_template("help.html")
@app3.route('/submit', methods=['POST'])

def submit():

    test1=int(request.form.get('test1'))
    test2=int(request.form.get('test2'))
    test3=int(request.form.get('test3'))

    result= model.predict(np.array([test1,test2,test3]).reshape(1,-1))

    if 90 < result < 100:
        sentence="Remarks : Stay engaged, actively participate in class discussions and seeking clarification when needed."
        template=render_template('result.html',name="YOUR PREDICTED GRADE IS 'O'.",result=sentence)
        return template
    if 80 < result < 90:
        sentence = "Remarks : Break down tasks into manageable steps to avoid feeling overwhelmed."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A+' .", result=sentence)
        return template
    if 70 < result < 80:
        sentence = "Remarks : Set goals to improve grades and use them as motivation"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A' .", result=sentence)
        return template
    if 60 < result < 70:
        sentence = "Remarks : Proactively seek feedback from teachers to identify areas for improvement."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B+' .", result=sentence)
        return template
    if 50 < result < 60:
        sentence = "Remarks : Take responsibility for academic progress and prioritize consistent effort"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B' .", result=sentence)
        return template
    if result < 50:
        sentence = "Remarks : Develop a plan to address areas of struggle and seek help"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'U-Reappearance' .", result=sentence)
        return template


@app3.route('/theory-paper')
def practical():

    return render_template('practical.html')

@app3.route('/practical-paper')
def practical_():

    return render_template('practical_.html')
@app3.route('/process', methods=['POST'])

def submit1():

    test1=int(request.form.get('test1'))
    test2=int(request.form.get('test2'))
    test3=int(request.form.get('test3'))
    test4 = float(request.form.get('test4'))
    test5 = int(request.form.get('test5'))
    test6 = int(request.form.get('test6'))

    result= model1.predict(np.array([test1,test2,test3,test4,test5,test6]).reshape(1,-1))
    if 90 < result < 100:
        sentence = "Remarks : Stay engaged, actively participate in class discussions and seeking clarification when needed."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'O'.", result=sentence)
        return template
    if 80 < result < 90:
        sentence = "Remarks : Break down tasks into manageable steps to avoid feeling overwhelmed."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A+' .", result=sentence)
        return template
    if 70 < result < 80:
        sentence = "Remarks : Set goals to improve grades and use them as motivation"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A' .", result=sentence)
        return template
    if 60 < result < 70:
        sentence = "Remarks : Proactively seek feedback from teachers to identify areas for improvement."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B+' .", result=sentence)
        return template
    if 50 < result < 60:
        sentence = "Remarks : Take responsibility for academic progress and prioritize consistent effort"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B' .", result=sentence)
        return template
    if result < 50:
        sentence = "Remarks : Develop a plan to address areas of struggle and seek help"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'U-Reappearance' .", result=sentence)
        return template

@app3.route('/marks', methods=['POST'])

def submit2():

    test1=int(request.form.get('test1'))
    test2=int(request.form.get('test2'))
    test3=int(request.form.get('test3'))
    test4 = float(request.form.get('test4'))
    test5 = int(request.form.get('test5'))

    result= model2.predict(np.array([test1,test2,test3,test4,test5]).reshape(1,-1))

    if 90 < result < 100:
        sentence = "Remarks : Stay engaged, actively participate in class discussions and seeking clarification when needed."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'O'.", result=sentence)
        return template
    if 80 < result < 90:
        sentence = "Remarks : Break down tasks into manageable steps to avoid feeling overwhelmed."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A+' .", result=sentence)
        return template
    if 70 < result < 80:
        sentence = "Remarks : Set goals to improve grades and use them as motivation"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'A' .", result=sentence)
        return template
    if 60 < result < 70:
        sentence = "Remarks : Proactively seek feedback from teachers to identify areas for improvement."
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B+' .", result=sentence)
        return template
    if 50 < result < 60:
        sentence = "Remarks : Take responsibility for academic progress and prioritize consistent effort"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'B' .", result=sentence)
        return template
    if result < 50:
        sentence = "Remarks : Develop a plan to address areas of struggle and seek help"
        template = render_template('result.html', name="YOUR PREDICTED GRADE IS 'U-Reappearance' .", result=sentence)
        return template

if __name__ == '__main__':
    app3.run(port=8080,debug=True)